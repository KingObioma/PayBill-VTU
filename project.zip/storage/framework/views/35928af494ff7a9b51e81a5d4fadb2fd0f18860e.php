<!-- Testimonial section start -->
<?php if(isset($templates['testimonial'][0]) && $testimonial = $templates['testimonial'][0]): ?>
	<section class="testimonial-section">
		<div class="container">
			<div class="row">
				<div class="section-header mb-50 text-center">
					<div class="section-subtitle"><?php echo app('translator')->get(optional($testimonial->description)->heading); ?></div>
					<h2 class=""><?php echo app('translator')->get(wordSplice(optional($testimonial->description)->title,1)['normal']); ?> <span
							class="highlight"><?php echo app('translator')->get(wordSplice(optional($testimonial->description)->title,1)['highLights']); ?></span>
					</h2>
					<p class="cmn-para-text m-auto"><?php echo app('translator')->get(optional($testimonial->description)->short_description); ?> </p>
				</div>
			</div>
			<?php if(isset($contentDetails['testimonial']) && $testimonials = $contentDetails['testimonial']): ?>
				<div class="row">
					<div class="owl-carousel owl-theme testimonial-carousel">
						<?php $__currentLoopData = $testimonials->sortBy('desc'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item">
								<div class="testimonial-box">
									<div class="testimonial-header">
										<div class="testimonial-title-area">
											<div class="testimonial-thumbs">
												<img
													src="<?php echo e(getFile(optional(optional($testimonial->content)->contentMedia)->driver,optional(optional(optional($testimonial->content)->contentMedia)->description)->image)); ?>"
													alt="...">
											</div>
											<div class="testimonial-title">
												<h5><?php echo app('translator')->get(optional($testimonial->description)->name); ?></h5>
												<h6><?php echo app('translator')->get(optional($testimonial->description)->address); ?></h6>
											</div>
										</div>
										<div class="qoute-icon">
											<i class="fa-sharp fa-regular fa-quote-left"></i>
										</div>
									</div>
									<div class="quote-area">
										<p><?php echo app('translator')->get(optional($testimonial->description)->short_description); ?></p>
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</section>
<?php endif; ?>
<!-- Testimonial section end -->
<?php /**PATH D:\server\htdocs\billpay\project\resources\views/themes/basic/sections/testimonial.blade.php ENDPATH**/ ?>