<!-- Bottom Mobile Tab nav section start -->
<ul class="nav bottom-nav fixed-bottom d-lg-none">
	<li class="nav-item">
		<a class="nav-link" data-bs-toggle="offcanvas" role="button" aria-controls="offcanvasNavbar"
		   href="#offcanvasNavbar" aria-current="page"><i class="fa-light fa-list"></i></a>
	</li>
	<li class="nav-item">
		<a class="nav-link <?php echo e(menuActive('features')); ?>" href="<?php echo e(route('features')); ?>"><i class="fa-light fa-planet-ringed"></i></a>
	</li>
	<li class="nav-item">
		<a class="nav-link <?php echo e(menuActive('home')); ?>" href="<?php echo e(route('home')); ?>"><i class="fa-light fa-house"></i></a>
	</li>
	<li class="nav-item">
		<a class="nav-link <?php echo e(menuActive('contact')); ?>" href="<?php echo e(route('contact')); ?>"><i
				class="fa-light fa-address-book"></i></a>
	</li>
	<li class="nav-item">
		<a class="nav-link <?php echo e(menuActive('login')); ?>" href="<?php echo e(route('login')); ?>"><i class="fa-light fa-user"></i></a>
	</li>
</ul>
<!-- Bottom Mobile Tab nav section end -->
<?php /**PATH D:\server\htdocs\billpay\project\resources\views/themes/basic/partials/mobileNav.blade.php ENDPATH**/ ?>