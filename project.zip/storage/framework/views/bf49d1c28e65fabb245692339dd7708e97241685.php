
<?php if(!request()->routeIs('home')): ?>
	<!-- Banner section start -->
	<div class="banner-area">
		<div class="container">
			<div class="row ">
				<div class="col">
					<div class="breadcrumb-area">
						<h3><?php echo $__env->yieldContent('title'); ?></h3>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><i
										class="fa-light fa-house"></i> <?php echo app('translator')->get('Home'); ?></a>
							</li>
							<li class="breadcrumb-item active" aria-current="page"><?php echo $__env->yieldContent('title'); ?></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Banner section end -->
<?php endif; ?>
<?php /**PATH D:\server\htdocs\billpay\project\resources\views/themes/basic/partials/banner.blade.php ENDPATH**/ ?>