<!-- Footer Section start -->
<section class="footer-section pb-50">
	<div class="container">
		<div class="row gy-4 gy-sm-5">
			<div class="col-lg-4 col-sm-6">
				<div class="footer-widget">
					<div class="widget-logo mb-30">
						<a href="<?php echo e(route('home')); ?>"><img class="logo"
														 src="<?php echo e(getFile(config('basic.default_file_driver'),config('basic.footer_image'))); ?>"
														 alt="<?php echo e(config('basic.site_title')); ?>"></a>
					</div>
					<?php if($contactUs): ?>
						<p><?php echo e(optional($contactUs->description)->about_company); ?>

						</p>
					<?php endif; ?>
					<?php if(isset($contentDetails['social'])): ?>
						<div class="social-area mt-50">
							<ul class="d-flex">
								<?php $__currentLoopData = $contentDetails['social']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<a href="<?php echo e(optional(optional(optional($data->content)->contentMedia)->description)->social_link); ?>"><i
												class="<?php echo e(optional(optional(optional($data->content)->contentMedia)->description)->social_icon); ?>"></i></a>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<div class="col-lg-2 col-sm-6">
				<div class="footer-widget">
					<h5 class="widget-title"><?php echo app('translator')->get('Quick Links'); ?></h5>
					<ul>
						<li><a class="widget-link" href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
						<li><a class="widget-link" href="<?php echo e(route('about')); ?>"><?php echo app('translator')->get('About'); ?></a></li>
						<li><a class="widget-link" href="<?php echo e(route('blog')); ?>"><?php echo app('translator')->get('Blog'); ?></a></li>
						<li><a class="widget-link" href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
					</ul>
				</div>
			</div>
			<?php if(isset($contentDetails['pages'])): ?>
				<div class="col-lg-3 col-sm-6 pt-sm-0 pt-3 ps-lg-5">
					<div class="footer-widget">
						<h5 class="widget-title"><?php echo app('translator')->get('Company Policy'); ?></h5>
						<ul>
							<?php $__currentLoopData = $contentDetails['pages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><a class="widget-link"
									   href="<?php echo e(route('getLink', [slug($data->description->title),$data->content_id])); ?>"><?php echo app('translator')->get(optional($data->description)->title); ?></a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
				</div>
			<?php endif; ?>
			<?php if($contactUs): ?>
				<div class="col-lg-3 col-sm-6 pt-sm-0 pt-3">
					<div class="footer-widget">
						<h5 class="widget-title"><?php echo app('translator')->get('Contact Us'); ?></h5>
						<p class="contact-item"><i
								class="fa-regular fa-location-dot"></i> <?php echo e(optional($contactUs->description)->location); ?>

						</p>
						<p class="contact-item"><i
								class="fa-regular fa-envelope"></i> <?php echo e(optional($contactUs->description)->email); ?></p>
						<p class="contact-item"><i
								class="fa-regular fa-phone"></i> <?php echo e(optional($contactUs->description)->phone); ?></p>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<hr class="cmn-hr">
		<!-- Copyright-area-start -->
		<div class="copyright-area">
			<div class="row gy-4">
				<div class="col-sm-6">
					<p><?php echo app('translator')->get('Copyright'); ?> ©<?php echo e(date('Y')); ?> <a class="highlight"
															href="javascript:void(0)"><?php echo app('translator')->get($basic->site_title); ?></a> <?php echo app('translator')->get('All Rights Reserved'); ?>
					</p>
				</div>
				<?php if(isset($languages)): ?>
					<div class="col-sm-6">
						<div class="language">
							<?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="<?php echo e(route('language',$item->short_name)); ?>"
								   class="language"><?php echo app('translator')->get($item->name); ?></a>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<!-- Copyright-area-end -->
	</div>
</section>
<!-- Footer Section end -->
<?php /**PATH D:\server\htdocs\billpay\project\resources\views/themes/basic/partials/footer.blade.php ENDPATH**/ ?>