<!-- Newsletter secdtion start -->
<?php if(isset($templates['newsletter'][0]) && $newsletter = $templates['newsletter'][0]): ?>
	<section class="newsletter-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-xl-6 col-md-8">
					<div class="content-area">
						<div
							class="subscribe-small-text"><?php echo app('translator')->get(wordSplice(optional($newsletter->description)->title,1)['normal']); ?></div>
						<h1 class="subscribe-normal-text"><?php echo app('translator')->get(wordSplice(optional($newsletter->description)->title,1)['highLights']); ?></h1>
					</div>
					<form action="<?php echo e(route('subscribe')); ?>" method="post" class="newsletter-form subscribe-form">
						<?php echo csrf_field(); ?>
						<input type="email" class="form-control" id="inputEmail4"
							   placeholder="<?php echo app('translator')->get('Enter your mail'); ?>">
						<button type="submit" class="subscribe-btn"><?php echo app('translator')->get('Subscribe'); ?></button>
					</form>
					<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="text-danger"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>
<!-- Newsletter secdtion end -->
<?php /**PATH D:\server\htdocs\billpay\project\resources\views/themes/basic/sections/newsletter.blade.php ENDPATH**/ ?>