<!-- Nav section start -->
<nav class="navbar fixed-top navbar-expand-lg">
	<div class="container">
		<a class="navbar-brand logo" href="<?php echo e(route('home')); ?>"><img
				src="<?php echo e(getFile(config('basic.default_file_driver'),config('basic.logo_image'))); ?>"
				alt="<?php echo e(config('basic.site_title')); ?>"></a>
		<button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
				aria-controls="offcanvasNavbar">
			<i class="fa-light fa-list"></i>
		</button>
		<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbar">
			<div class="offcanvas-header">
				<a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img class="logo"
																	  src="<?php echo e(getFile(config('basic.default_file_driver'),config('basic.logo_image'))); ?>"
																	  alt="<?php echo e(config('basic.site_title')); ?>"></a>
				<button type="button" class="cmn-btn-close btn-close" data-bs-dismiss="offcanvas"
						aria-label="Close"><i class="fa-light fa-arrow-right"></i></button>
			</div>
			<div class="offcanvas-body align-items-center justify-content-between">
				<ul class="navbar-nav m-auto">
					<li class="nav-item">
						<a class="nav-link <?php echo e(menuActive('home')); ?>" aria-current="page"
						   href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('home'); ?></a>
					</li>
					<li class="nav-item">
						<a class="nav-link <?php echo e(menuActive('about')); ?>" href="<?php echo e(route('about')); ?>"><?php echo app('translator')->get('About'); ?></a>
					</li>
					<li class="nav-item">
						<a class="nav-link <?php echo e(menuActive('features')); ?>"
						   href="<?php echo e(route('features')); ?>"><?php echo app('translator')->get('features'); ?></a>
					</li>
					<li class="nav-item">
						<a class="nav-link <?php echo e(menuActive('blog')); ?>" href="<?php echo e(route('blog')); ?>"><?php echo app('translator')->get('blog'); ?></a>
					</li>
					<li class="nav-item">
						<a class="nav-link <?php echo e(menuActive('faq')); ?>" href="<?php echo e(route('faq')); ?>"><?php echo app('translator')->get('FAQ'); ?></a>
					</li>
					<li class="nav-item">
						<a class="nav-link <?php echo e(menuActive('contact')); ?>" href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a>
					</li>
				</ul>
				<form>
					<ul class="navbar-nav nav-right d-flex align-items-center">
						<?php if(auth()->guard()->guest()): ?>
							<li class="nav-item">
								<a class="nav-link" href="<?php echo e(route('login')); ?>"><i
										class="login-icon fa-regular fa-right-to-bracket"></i><?php echo app('translator')->get('Login'); ?></a>
							</li>
						<?php endif; ?>
						<?php if(auth()->guard()->check()): ?>
							<li class="nav-item">
								<a class="get-start-btn" href="<?php echo e(route('user.dashboard')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a>
							</li>
						<?php endif; ?>
						<li>
							<a id="toggle-btn" class="nav-link d-flex toggle-btn">
								<i class="fa-regular fa-moon" id="moon"></i>
								<i class="fa-regular fa-sun-bright" id="sun"></i>
							</a>
						</li>
					</ul>
				</form>

			</div>
		</div>
	</div>
</nav>
<!-- Nav section end -->
<?php /**PATH D:\server\htdocs\billpay\project\resources\views/themes/basic/partials/nav.blade.php ENDPATH**/ ?>