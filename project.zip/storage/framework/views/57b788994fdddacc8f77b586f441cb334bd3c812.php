<!-- Blog Section start -->
<?php if(isset($contentDetails['blog']) && $blogContents = $contentDetails['blog']->take(3)): ?>
	<section class="blog-section">
		<div class="container">
			<?php if(isset($templates['blog'][0]) && $blog = $templates['blog'][0]): ?>
				<div class="row">
					<div class="col-12">
						<div class="section-header text-center mb-50">
							<div class="section-subtitle"><?php echo app('translator')->get(optional($blog->description)->heading); ?></div>
							<h2 class="section-title mx-auto"><?php echo app('translator')->get(wordSplice(optional($blog->description)->title,1)['normal']); ?>
								<span
									class="highlight"><?php echo app('translator')->get(wordSplice(optional($blog->description)->title,1)['highLights']); ?></span>
							</h2>
							<p class="cmn-para-text mx-auto"><?php echo app('translator')->get(optional($blog->description)->short_description); ?></p>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<div class="row g-4">
				<?php $__currentLoopData = $blogContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-lg-4 col-md-6">
						<div class="blog-box">
							<div class="img-box">
								<a href="<?php echo e(route('blogDetails', $blogContent->content_id)); ?>">
									<img
										src="<?php echo e(getFile(optional(optional($blogContent->content)->contentMedia)->driver,optional(optional(optional($blogContent->content)->contentMedia)->description)->image)); ?>"
										alt="...">
								</a>

							</div>
							<div class="content-box">
								<div class="date">
									<p class="mb-0"><?php echo e(dateTime($blogContent->created_at,'M')); ?></p>
									<h4 class="mb-0"><?php echo e(dateTime($blogContent->created_at,'d')); ?></h4>
								</div>
								<div class="blog-title">
									<h5>
										<a href="<?php echo e(route('blogDetails', $blogContent->content_id)); ?>"><?php echo e(optional($blogContent->description)->title); ?>

										</a></h5>
								</div>
								<div class="para-text">
									<p><?php echo app('translator')->get(Str::limit(optional($blogContent->description)->description,200)); ?></p>
								</div>
								<a href="<?php echo e(route('blogDetails', $blogContent->content_id)); ?>"
								   class="blog-btn"><?php echo app('translator')->get('Read more'); ?></a>
							</div>

						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
<?php endif; ?>
<!-- Blog Section end -->
<?php /**PATH D:\server\htdocs\billpay\project\resources\views/themes/basic/sections/blog.blade.php ENDPATH**/ ?>