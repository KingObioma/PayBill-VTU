<!-- Faq section start -->
<?php if(isset($contentDetails['faq'])): ?>
	<section class="faq-section">
		<div class="container-fluid">
			<div class="row g-5 align-items-center">
				<?php if(isset($templates['faq'][0]) && $faq = $templates['faq'][0]): ?>
					<div class="col-lg-6 ps-md-0">
						<div class="faq-thum">
							<img src="<?php echo e(getFile(optional($faq->media)->driver,@$faq->templateMedia()->image)); ?>"
								 alt="...">
						</div>
					</div>
				<?php endif; ?>
				<div class="col-lg-6">
					<div class="faq-content">
						<?php if(isset($templates['faq'][0]) && $faq = $templates['faq'][0]): ?>
							<div class="section-subtitle"><?php echo app('translator')->get(optional($faq->description)->heading); ?></div>
							<h2><?php echo app('translator')->get(wordSplice(optional($faq->description)->title,1)['normal']); ?> <span
									class="highlight"><?php echo app('translator')->get(wordSplice(optional($faq->description)->title,1)['highLights']); ?></span>
							</h2>
							<p class="cmn-para-text mx-auto"><?php echo app('translator')->get(optional($faq->description)->short_description); ?>
							</p>
						<?php endif; ?>
						<div class="accordion" id="accordionExample2">
							<?php $__currentLoopData = $contentDetails['faq']->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="accordion-item">
									<h2 class="accordion-header" id="headin<?php echo e($key); ?>">
										<button class="accordion-button" type="button" data-bs-toggle="collapse"
												data-bs-target="#collapse<?php echo e($key); ?>" aria-expanded="true"
												aria-controls="collapse<?php echo e($key); ?>">
											<?php echo app('translator')->get(optional($item->description)->title); ?>
										</button>
									</h2>
									<div id="collapse<?php echo e($key); ?>"
										 class="accordion-collapse collapse <?php echo e($key == 0 ? 'show':''); ?>"
										 aria-labelledby="headin<?php echo e($key); ?>" data-bs-parent="#accordionExample2">
										<div class="accordion-body">
											<div class="table-responsive">
												<p><?php echo app('translator')->get(optional($item->description)->short_description); ?></p>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>
<!-- Faq section end -->
<?php /**PATH D:\server\htdocs\billpay\project\resources\views/themes/basic/sections/faq.blade.php ENDPATH**/ ?>