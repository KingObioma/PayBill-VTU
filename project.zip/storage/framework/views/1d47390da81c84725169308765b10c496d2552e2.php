<!-- How it works section start -->
<?php if(isset($contentDetails['how-it-work'][0]) && $how_it_works = $contentDetails['how-it-work'][0]): ?>
	<section class="how-it-work">
		<div class="container">
			<?php if(isset($templates['how-it-work'][0]) && $how_it_work = $templates['how-it-work'][0]): ?>
				<div class="row">
					<div class="col-12">
						<div class="section-header text-center mb-50">
							<div class="section-subtitle"><?php echo app('translator')->get(optional($how_it_work->description)->heading); ?></div>
							<h2 class="section-title mx-auto"><?php echo app('translator')->get(wordSplice(optional($how_it_work->description)->title,2)['normal']); ?>
								<span
									class="highlight"><?php echo app('translator')->get(wordSplice(optional($how_it_work->description)->title,2)['highLights']); ?></span>
							</h2>
							<p class="cmn-para-text mx-auto"><?php echo app('translator')->get(optional($how_it_work->description)->short_description); ?>
							</p>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<?php if(isset($contentDetails['how-it-work']) && $how_it_works = $contentDetails['how-it-work']): ?>
				<div class="row g-4 g-xxl-5 align-items-center">
					<?php $__currentLoopData = $how_it_works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4 col-sm-6 cmn-box-item">
							<div class="cmn-box">
								<div class="icon-box">
									<i class="<?php echo e(optional(optional($value->content)->contentMedia)->description->icon); ?>"></i>
									<div class="number"><?php echo e(++$key); ?></div>
								</div>
								<div class="text-box">
									<h5><?php echo app('translator')->get(optional($value->description)->title); ?></h5>
									<span><?php echo app('translator')->get(optional($value->description)->short_description); ?></span>
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			<?php endif; ?>
		</div>
	</section>
<?php endif; ?>
<!-- How it works section start -->
<?php /**PATH D:\server\htdocs\billpay\project\resources\views/themes/basic/sections/how-it-work.blade.php ENDPATH**/ ?>