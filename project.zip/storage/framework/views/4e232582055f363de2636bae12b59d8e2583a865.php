<!-- Feature section start -->
<?php if(isset($contentDetails['feature'][0]) && $featureContents = $contentDetails['feature'][0]): ?>
	<section class="feature-section">
		<div class="container">
			<?php if(isset($templates['feature'][0]) && $feature = $templates['feature'][0]): ?>
				<div class="row">
					<div class="section-header text-center">
						<div class="section-subtitle"><?php echo app('translator')->get(optional($feature->description)->heading); ?></div>
						<h2 class="section-title text-center mx-auto"><?php echo app('translator')->get(wordSplice(optional($feature->description)->title,1)['normal']); ?>
							<span
								class="highlight"><?php echo app('translator')->get(wordSplice(optional($feature->description)->title,1)['highLights']); ?></span>
						</h2>
						<p class="cmn-para-text mx-auto"><?php echo app('translator')->get(optional($feature->description)->short_description); ?></p>
					</div>
				</div>
			<?php endif; ?>
			<div class="row g-4">
				<?php if(isset($contentDetails['feature']) && $featureContents = $contentDetails['feature']): ?>
					<?php $__currentLoopData = $featureContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $featureContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-4 col-sm-6 cmn-box-item">
							<div class="cmn-box">
								<div class="icon-box">
									<i class="<?php echo e(optional(optional($featureContent->content)->contentMedia)->description->icon); ?>"></i>
								</div>
								<div class="text-box">
									<h5 class="title"><?php echo app('translator')->get(optional($featureContent->description)->title); ?></h5>
									<span><?php echo app('translator')->get(optional($featureContent->description)->short_description); ?></span>
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</div>
		</div>
	</section>
<?php endif; ?>
<!-- Feature section end -->
<?php /**PATH D:\server\htdocs\billpay\project\resources\views/themes/basic/sections/feature.blade.php ENDPATH**/ ?>