<!-- App section start -->
<section class="app-section">
	<div class="container">
		<div class="row g-4 g-lg-5 align-items-center">
			<?php if(isset($templates['app-section'][0]) && $app = $templates['app-section'][0]): ?>
				<div class="col-lg-6">
					<div class="app-content">
						<h3 class="mb-0"><?php echo app('translator')->get(optional($app->description)->title); ?>
						</h3>
					</div>
				</div>
			<?php endif; ?>
			<?php if(isset($contentDetails['app-section']) && $appSectionContents = $contentDetails['app-section']): ?>
				<div class="col-lg-6 d-flex justify-content-center justify-lg-content-end">
					<div class="app-btn-area">
						<?php $__currentLoopData = $appSectionContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $appSectionContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a href="<?php echo e(optional(optional($appSectionContent->content)->contentMedia)->description->button_link); ?>"
							   class="app-btn">
								<div class="icon-area">
									<i class="<?php echo e(optional(optional($appSectionContent->content)->contentMedia)->description->icon); ?>"></i>
								</div>
								<div class="content-area">
									<p class="mb-0"><?php echo app('translator')->get('Download on'); ?></p>
									<h5 class="mb-0"><?php echo app('translator')->get(optional($appSectionContent->description)->title); ?></h5>
								</div>
							</a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>
<!-- App section end -->
<?php /**PATH D:\server\htdocs\billpay\project\resources\views/themes/basic/sections/app-section.blade.php ENDPATH**/ ?>