@extends($theme.'layouts.app')
@section('title',trans('Home'))

@section('content')

	@include($theme.'sections.hero')
	@include($theme.'sections.feature')
	@include($theme.'sections.about-us')

	@include($theme.'sections.how-it-work')
	@include($theme.'sections.why-choose-us')
	@include($theme.'sections.testimonial')
	@include($theme.'sections.faq')

	@include($theme.'sections.blog')
	@include($theme.'sections.app-section')
	@include($theme.'sections.newsletter')

@endsection
