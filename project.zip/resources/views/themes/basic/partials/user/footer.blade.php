<!-- Footer section start -->
<footer id="footer" class="footer">
	<div class="copyright">
		&copy; @lang('Copyright')
		<strong><span>{{ __(basicControl()->site_title) }}</span></strong>. @lang('All Rights Reserved')
	</div>
</footer>
<!-- Footer section end -->



