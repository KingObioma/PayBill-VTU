<div class="empty-state">
	<div class="empty-state__content">
		<div class="empty-state__icon">
			<img
				src="{{asset($themeTrue.'images/no_record_found.png')}}" alt="...">
		</div>
		<div class="empty-state__message">@lang('No records has been added yet.')</div>
	</div>
</div>
