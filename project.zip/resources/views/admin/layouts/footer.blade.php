<!-- Footer -->
<footer class="main-footer">
	<div class="footer-left">
		@lang('Copyright') &copy; {{ __(date('Y')) }} <div class="bullet"></div> @lang('All rights reserved by')
		<b>{{ __(basicControl()->site_title) }}</b>
	</div>

	<div class="footer-right">

	</div>
</footer>
